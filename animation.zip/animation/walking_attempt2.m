world = vrworld('walking_attempt1.wrl', 'new');
open(world);
fig=vrfigure(world);
vrdrawnow;

man_node = vrnode(world, 'man');

left_thigh_node = vrnode(world, 'left_thigh');
left_leg_node = vrnode(world, 'left_leg');
left_foot_node = vrnode(world, 'left_foot');

right_thigh_node = vrnode(world, 'right_thigh');
right_leg_node = vrnode(world, 'right_leg');
right_foot_node = vrnode(world, 'right_foot');


%starting and ending point coordinates            
x = 0.1:0.1:5;
z = zeros(size(x));
y = zeros(size(x));

man_node.translation = [0.1 0 0];

%walk in a straight line
for i=1:length(x)   
    
    waist_and_groin_node.rotation = [1 0 0 -0.25];
    right_thigh_node.rotation = [1 0 0 -0.25];
    right_leg_node.rotation = [1 0 0 -0.25];
    right_foot_node.rotation = [1 0 0 -0.25];

    pause(0.1);

    waist_and_groin_node.rotation = [0 0 0 0];
    right_thigh_node.rotation = [0 0 0 0];
    right_leg_node.rotation = [0 0 0 0];
    right_foot_node.rotation = [0 0 0 0];

    pause(0.1);

    waist_and_groin_node.rotation = [1 0 0 -0.25];
    left_thigh_node.rotation = [1 0 0 -0.25];
    left_leg_node.rotation = [1 0 0 -0.25];
    left_foot_node.rotation = [1 0 0 -0.25];

    pause(0.1);

    waist_and_groin_node.rotation = [0 0 0 0];
    left_thigh_node.rotation = [0 0 0 0];
    left_leg_node.rotation = [0 0 0 0];
    left_foot_node.rotation = [0 0 0 0];

    pause(0.1);

    man_node.translation = [x(i) y(i) z(i)];
    vrdrawnow;
    pause(0.1);
end

%stop with body in original position
waist_and_groin_node.rotation = [0 0 0 0];
left_thigh_node.rotation = [0 0 0 0];
left_leg_node.rotation = [0 0 0 0];
left_foot_node.rotation = [0 0 0 0];

pause(0.15);

waist_and_groin_node.rotation = [0 0 0 0];
right_thigh_node.rotation = [0 0 0 0];
right_leg_node.rotation = [0 0 0 0];
right_foot_node.rotation = [0 0 0 0];

pause(0.15);

%man_node.rotation = [0, 1, 0, 6.3];  
%vrdrawnow;

%starting and ending point coordinates
%z2 = 0:0.1:8;
%x2 = 5 + zeros(size(z2));
%y2 = zeros(size(z2));

%walk in a straight line
%for i=1:length(z2)
    
 %   waist_and_groin_node.rotation = [0 0 1 -0.25];
 %   right_thigh_node.rotation = [0 0 1 -0.25];
 %   right_leg_node.rotation = [0 0 1 -0.25];
  %  right_foot_node.rotation = [0 0 1 -0.25];

%    pause(0.15);

 %   waist_and_groin_node.rotation = [0 0 0 0];
  %  right_thigh_node.rotation = [0 0 0 0];
   % right_leg_node.rotation = [0 0 0 0];
    %right_foot_node.rotation = [0 0 0 0];
    
    %pause(0.15);
    
    %waist_and_groin_node.rotation = [0 0 1 -0.25];
    %left_thigh_node.rotation = [0 0 1 -0.25];
    %left_leg_node.rotation = [0 0 1 -0.25];
    %left_foot_node.rotation = [0 0 1 -0.25];

    %pause(0.15);

    %waist_and_groin_node.rotation = [0 0 0 0];
    %left_thigh_node.rotation = [0 0 0 0];
    %left_leg_node.rotation = [0 0 0 0];
    %left_foot_node.rotation = [0 0 0 0];
    
    %man_node.translation = [x2(i) y2(i) z2(i)];
    %vrdrawnow;
    %pause(0.15);
%end

%stop with body in original position
%waist_and_groin_node.rotation = [0 0 0 0];
%right_thigh_node.rotation = [0 0 0 0];
%right_leg_node.rotation = [0 0 0 0];
%right_foot_node.rotation = [0 0 0 0];

%pause(0.15);

%waist_and_groin_node.rotation = [0 0 0 0];
%left_thigh_node.rotation = [0 0 0 0];
%left_leg_node.rotation = [0 0 0 0];
%left_foot_node.rotation = [0 0 0 0];