%% Create a World Object
world = vrworld('new_village.wrl');

%% Open and View the World
open(world);

fig = view(world, '-internal');
vrdrawnow;

%% Examine the Virtual World Properties
get(world)

%% Finding Nodes of the World
nodes(world)

%% Accessing VRML Nodes
bike_and_boy = vrnode(world, 'bike_and_boy')
pedal = vrnode(world, 'pedals')

%% Viewing Fields of Nodes
fields(bike_and_boy)

%% Moving the bike_and_boy Node
z1 = 218.5:2:360;
x1 = -726.5 + zeros(size(z1));
y1 = -31.5 + zeros(size(z1));

x2 = -726.5:2:900;
z2 = 360 + zeros(size(x2));
y2 = -31.5 + zeros(size(z2));

z3 = 360:-2:350;
x3 = 900 + zeros(size(z3));
y3 = -31.5 + zeros(size(x3));

for i=1:length(z1)   
    bike_and_boy.translation = [x1(i) y1(i) z1(i)];
    vrdrawnow;
    pause(0.01);
end

bike_and_boy.rotation = [0, 1, 0, -1.5708];
vrdrawnow;

for i=1:length(x2)
    %pedal.rotation = [0, 0, 1, 0.5];
    bike_and_boy.translation = [x2(i) y2(i) z2(i)];
    vrdrawnow;    
    pause(0.01);
end

%bike_and_boy.rotation = [0, 1, 0, -1.5708];
%vrdrawnow;

%for i=1:length(x3)
    %bike_and_boy.translation = [x3(i) y3(i) z3(i)];
    %vrdrawnow;
    %pause(0.1);
%end

reload(world);
vrdrawnow;

%% Preserve the Virtual World Object in the MATLAB(R) Workspace 
clear ans car i x1 x2 x3 y1 y2 y3 z1 z2 z3


displayEndOfDemoMessage(mfilename)

