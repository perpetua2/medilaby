[X,map] = imread('blood.jpg');
imshow(X,map)
newmap = map;
newmap(:,1)= 0;
colormap(gca,newmap)