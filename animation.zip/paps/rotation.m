% rotating the points
x=[1 2 3 1];
y=[1 3 1 1]; 
x1=[6 7 8 6]
y1=[4 6 4 4] 
title('triangle operations');
subplot( 1,2,1);
plot(x,y);
axis([0 10 0 10]);
title ('triangle original');
xlabel('X-Axis');
ylabel('Y-Axis');
r=[x;y;1 1 1 1];

