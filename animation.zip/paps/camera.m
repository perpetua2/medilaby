%Read Image
i = imread('camera.jpg');

I = rgb2gray(i);
figure,imshow(I);

%binary conversion
bw = im2bw(I,0.03);

figure,imshow(bw);

bw = im2bw(I,0.0);

figure,imshow(bw);

bw = im2bw(I,0.2);

figure,imshow(bw);

bw = im2bw(I,0.4);

figure,imshow(bw);
%% 
    %%
