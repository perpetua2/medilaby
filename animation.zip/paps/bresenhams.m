p1 = input('Give coord x0 : ');
p1(2) = input('Give coord y0 : ');
p2 = input('Give coord x1 : ');
p2(2) = input('Give coord y1 : ');
dy=p2(2)-p1(2);
dx=p2(1)-p1(1);
m=dy/dx;
if m<1
    x=p1(1);y=p1(2);
    pk=2*dy-dx;
    if pk>=0
        y(2)=y(1)+1;
        x(2)=x(1)+1;
    elseif pk<0
           x(2)=x(1)+1;
           y(2)=y(1);
    end
  k = p2(1)-p1(1);
for i=2:k
    pk(i)=pk(i-1)+2*dy-2*dx*(y(i)-y(i-1));
  if pk(i)>=0
        y(i+1)=y(i)+1;
        x(i+1)=x(i)+1;
    elseif pk(i)<0
           x(i+1)=x(i)+1;
           y(i+1)=y(i);
  end
 

end
plot(x,y);
grid on
end
if m>1
    x=p1(1);y=p1(2);
    pk=2*dx-dy;
    if pk>=0
        y(2)=y(1)+1;
        x(2)=x(1)+1;
    elseif pk<0
           x(2)=x(1);
           y(2)=y(1)+1;
    end
    k = p2(2)-p1(2);
for i=2:k
    pk(i)=pk(i-1)+2*dx-2*dy*(x(i)-x(i-1));
    
     disp(pk)
  if pk(i)>=0
        y(i+1)=y(i)+1;
        x(i+1)=x(i)+1;
    elseif pk(i)<0
           x(i+1)=x(i);
           y(i+1)=y(i)+1;
  end
 

end
plot(x,y);
grid on
end
if m==0
x=p1(1);y=p1(2);
k = p2(2)-p1(2);
for i=1:k
    x(i+1)=x(i)+1;
    y(i+1)=y(i)+1;

end
plot(x,y);
grid on
end

