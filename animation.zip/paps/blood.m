%Read image
x=imread('blood.jpg');

figure,imshow(x);

%Histogram
figure,imhist(I);

%Colour
figure, imshow(x), colormap(jet(16));

figure, imshow(x), colormap(jet(32));