h = imshow('cameraman.jpg');
[nrows,ncols] = size(get(h,'CData'));
xdata = get(h,'XData')
ydata = get(h,'YData')
px = axes2pix(ncols,xdata,30)
py = axes2pix(nrows,ydata,30)