x=[2 5 5 2 2];
y=[2 2 8 8 2];
plot(x,y);
% to set both axis from 0 to 5
xlim([0,10])
ylim([0,10])
% to set the increment in each axis to 1
% or replace these lines:
% x = [1 1 3 3 1 1 3];
% y = [4 2 2 4 4 4 2];
% plot(x,y,'r', 'LineWidth',1)
% by 
% rectangle('Position',[1 2 2 2]);
% for simplicity
x=[2 2 6 6];
y=[2 8 8 2];
rect=fill(x,y,'black');
theta = 45;
v=[cosd(theta) -sind(theta) 0;sind(theta) cosd(theta) 0;0 0 1];
s=get(rect,'vertices')';
a=[1 1 1 1];
s=[s;a];
w=v*s;
x1=w(1:1,:);
y1=w(2:2,:);
rect2=fill(x1,y1,'black');
axis([-20 50 -20 50])