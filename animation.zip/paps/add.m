I = imread('LenaGray.png');
J = imread('FruitsGray.png');
K = imlincomb(1,I,1,J,'uint16');
imshow(K,[])
figure;;
imhist(K);