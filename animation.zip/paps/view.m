[x,y] = meshgrid([-2:0.1:2])
z= x.*exp(-x.^2-y.^2)
z_m=zeros(size(z))

surf(x,y,z)

view(-37.5,10) 
