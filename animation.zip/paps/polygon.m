t=(1/16:1/8:1)'*2*pi;
x=sin(t);
y=cos(t);
fill(x,y,'b');
axis square