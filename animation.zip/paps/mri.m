load  mri      
D = squeeze(D);    
figure('Colormap',map)
image_num = 8;
image(D(:,:,image_num))
axis image

contourslice(D,[],[], 10, 5)%

