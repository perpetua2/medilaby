%scalling the points
x=[2 5 5 2 2];
y=[2 2 8 8 2];
title('Rectangle operations');
subplot( 1,2,1);
plot(x,y);
axis([0 10 0 10]);
title ('rectangle original');
xlabel('X-Axis');
ylabel('Y-Axis');
scale1=x.*1.5;
scale2=y.*0.5;
subplot(1,4,3);
plot(scale1,scale2);
axis([0 10 0 10]);
title('The Scaled Rectangle');
xlabel('X-Axis');
ylabel('Y-Axis');