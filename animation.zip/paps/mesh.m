 [x,y]=meshgrid(1:3, 1:3); 
 figure;
 
[x,y]=meshgrid([-3.0:0.1:3.0],[-3.0:0.1:3.0])
z=exp(-power(x,2))