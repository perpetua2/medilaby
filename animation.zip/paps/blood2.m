I = imread('blood.jpg');
figure(1), imshow(I);
figure(2), imshow(I), colormap(jet(16))
figure(3), imshow(I), colormap winter;
figure(4), imshow(I), colormap autumn;
figure(5), imshow(I), colormap summer;
figure(6), imshow(I), colormap pink;
figure(7), imshow(I), colormap lines;