x_start=-1.0;
x_end=1.0;
x_sub=0.2;
Nx=(x_end-x_start)/x_sub
x_value=x_start:x_sub:x_end;

% define the sample points along the y-axis
y_start=-1.0;
y_end=1.0;
y_sub=0.2;
Ny = (y_end-y_start)/y_sub
y_value=y_start:y_sub:y_end;
 for i=[1:Nx+1]
     for j=[1:Ny+1]
         f(i,j)=exp(-(power(x_value(i),2)+power(y_value(j),2)));

     end
 end
 %Show the Figure in Window 1 
figure(1); 
surf(x_value,y_value,f);

 %set up the green color 

colormap([0,1,0])
light('Position',[-1,-1,0.5],'Style','infinite'); 

lighting flat
alpha(0.2); 
 [x,y,z]=peaks;
pcolor(x,y,z)
shading interp      %[flat; faceted]  shading in color, not in lighting
hold on
contour(x,y,z,20,'k')
hold off


%define the limit of the axis 
xlim([-1.0,1.0]); 
ylim([-1.0,1.0]);






  