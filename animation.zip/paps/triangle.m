% rotating the points
x=[1 3 4 1];
y=[1 4 1 1]; 
x1=[8 7 8 6]
y1=[6 8 4 4] 
title('triangle operations');
subplot( 1,2,1);
plot(x,y);
axis([0 10 0 10]);
title ('triangle original');
xlabel('X-Axis');
ylabel('Y-Axis');
