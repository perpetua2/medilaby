x=[1 3 3 1 1];
y=[1 1 6 6 1];
x1=[1 5 5 1 1];
y1=[1 1 7 7 1]; 
title('triangle operations');
subplot( 1,4,1);
plot(x,y);
axis([0 10 0 10]);
title (' rectangle original');
xlabel('X-Axis');
ylabel('Y-Axis');
subplot(1,7,5);
plot(x1,y1);
axis([0 10 0 10]);
title('The Translated Triangle');
xlabel('X-Axis');
ylabel('Y-Axis');



