x=5;
y=5;
r=10
theta = 0 : 0.01 : 2*pi;
x = r * cos(theta) + x;
y = r * sin(theta) + y;
plot(x, y,'g');
axis square;
title('Circle Line drawing ')