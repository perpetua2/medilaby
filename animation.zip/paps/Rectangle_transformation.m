%translation
trans = figure;
x = [2 9 9 2 2];
y = [2 2 8 8 2];
z = [1 1 1 1 1];
x2 = x + [8 8 8 8 8];
y2 = y + [0 0 0 0 0];
figure(trans);
plot(x, y, x2, y2);
axis([0 20 0 20]);
title('The translation');

%rotation
rotate = figure;
rotatex = [];
rotatey = [];
for index = [1 2 3 4 5]
    co = [x(index); y(index)];
    c = mtimes([cos(45) sin(45); -sin(45) cos(45)], co);
    rotatex(index) = c(1);
    rotatey(index) = c(2);
end

figure(rotate);
plot(x, y, rotatex, rotatey);
axis([-5 20 -15 20]);
title('The rotation');


%composite matrix
compositefigure = figure;
rotation = [cos(30) sin(30); -sin(30) cos(30)];
scaling = [1 0; 0 1];
translation = [6 0; 6 0];
composite = rotation*scaling + translation;
compx = [];
compy = [];
for index = [1 2 3 4 5]
    compco = [x(index); y(index)];
    comp = composite * compco;
    compx(index) = comp(1);
    compy(index) = comp(2);
end
figure(compositefigure);
plot(x, y, compx, compy);
axis([-15 80 -15 80]);
title('The RST');