load mri;
montage(D,map)
title('Horizontal Slices');