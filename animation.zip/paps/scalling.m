%scalling the points
x=[1 2 3 1];
y=[1 3 1 1];
title('triangle operations');
subplot( 1,2,1);
plot(x,y);
axis([0 10 0 10]);
title ('triangle original');
xlabel('X-Axis');
ylabel('Y-Axis');
scale1=x.*1.5;
scale2=y.*0.2;
subplot(1,4,3);
plot(scale1,scale2);
axis([0 10 0 10]);
title('The Scaled Triangle');
xlabel('X-Axis');
ylabel('Y-Axis');
