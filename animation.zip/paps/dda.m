
p1 = input('Give coord x0 : ');
p1(2) = input('Give coord y0 : ');
p2 = input('Give coord x1 : ');
p2(2) = input('Give coord y1 : ');
dy=p2(2)-p1(2);
dx=p2(1)-p1(1);
m=dy/dx;

if m>1
x=p1(1);y=p1(2);
for i=1:p2(2)
    x(i+1)=x(i)+1/m;
    y(i+1)=y(i)+1;
end
plot(round(x),y);
grid on
end

if m< 1
x=p1(1);y=p1(2);
for i=1:p2(1)
    x(i+1)=x(i)+1;
    y(i+1)=y(i)+m;
end
plot(round(x),round(y));
grid on
end

if m==0
x=p1(1);y=p1(2);
for i=1:p2(2)
    x(i+1)=x(i)+1;
    y(i+1)=y(i)+1;

end
plot(round(x),y);
grid on
end
