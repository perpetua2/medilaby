x=[2 2 6 6];
y=[2 8 8 2];
rect=fill(x,y,'black');
s=[2 0 0;0 2 0;0 0 1];
d=30;
r=[cosd(d) -sind(d) 0;sind(d) cosd(d) 0; 0 0 1];
t=[1 0 5;0 1 5;0 0 1];
first=t*s;
sec=first*r;
s1=get(rect,'vertices')';
a=[1 1 1 1];
s1=[s1;a];
final=sec*s1;
x1=final(1:1,:);
y1=final(2:2,:);
rect2=fill(x1,y1,'black');
axis([0 50 0 50])