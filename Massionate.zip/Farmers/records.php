﻿
<?php
	  $servername = "localhost";
	  $username = "root";
	  $password = "";
	  $dbname = "farmers";
	  
	  // Create connection
	  $conn = mysqli_connect($servername, $username, $password, $dbname);
	  // Check connection
	  if (!$conn) {
	      die("Connection failed: " . mysqli_connect_error());
	  }
	$sql = "SELECT GroupName,GroupChairPerson,GroupMembers,GroupKRAPIN,TypeOfFarming,Email,Phone,County FROM register";
	$result1 = mysqli_query($conn,$sql);
	$result2 = mysqli_query($conn,$sql);
	$datarow ="";
	while ($row2 = mysqli_fetch_array($result2)) {
		$datarow = $datarow."<tr><td>$row2[0]</td><td>$row2[1]</td><td>$row2[2]</td><td>$row2[3]</td><td>$row2[4]</td><td>$row2[5]</td><td>$row2[6]</td><td>$row2[7]</td></tr>";
		
	}
	mysqli_close($conn);

	?>

		<div>
			<table width="1300" border="1" cellpadding="1" cellspacing="1">
 		<tr>
 			<th>GroupName</th>
 			<th>GroupChairPerson</th>
 			<th>GroupMembers</th>
 			<th>GroupKRAPIN</th>
 			<th>TypeOfFarming</th>
 			<th>Email</th>
 			<th>Phone</th>
 			<th>County</th>
 		</tr>

 		<?php 
 		while ($row1 = mysqli_fetch_array($result1)):;?>
 		<tr>
 			<td><?php echo $row1[0] ;?></td>
 			<td><?php echo $row1[1] ;?></td>
 			<td><?php echo $row1[2] ;?></td>
 			<td><?php echo $row1[3] ;?></td>
 			<td><?php echo $row1[4] ;?></td>
 			<td><?php echo $row1[5] ;?></td>
 			<td><?php echo $row1[6] ;?></td>
 			<td><?php echo $row1[7] ;?></td>
 		</tr>
 			
 		 <?php endwhile;?>
 <html>
 <title>farmerspridewelfaregroup&reg</title>
<head>
<style>
tr:nth-child(even){background-color:yellow;
}
tr:nth-child(odd){background-color:grey;
}
body{background-color:cyan ;}
body{text-align:center;}
</style>
<h1 style="color:red";>Registered FarmersGroups Records&reg</h1>
<style>
@media screen and (max-width: 320px)
{@viewport{ width:320px;}} @media screen and (min-width:768px) and (max-width:959px) { @viewport{width: 768px;}}
</style>
</head>
<body>
<li><a href="Home.html"><b><i>Previous</b></i></a></li><br><br></body>
</html>