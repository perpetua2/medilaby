﻿<?php
	if(!empty($_POST["forgot-password"])){
		$conn = mysqli_connect("localhost", "root", "", "farmers");
		
		$condition = "";
		if(!empty($_POST["name"])) 
			$condition = " name = '" . $_POST["name"] . "'";
		if(!empty($_POST["gmail"])) {
			if(!empty($condition)) {
				$condition = " and ";
			}
			$condition = " gmail = '" . $_POST["gmail"] . "'";
		}
		
		if(!empty($condition)) {
			$condition = " where " . $condition;
		}

		$sql = "Select * from login " . $condition;
		$password = mysqli_query($conn,$sql);
		$user = mysqli_fetch_array($password);
		
	
		if(!empty($user)) {
			require_once("forgot-password-recovery-mail.php");
		} else {
			$error_message = 'No User Found';
		}
	}
?>