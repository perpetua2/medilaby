
<!DOCTYPE html>
<html>
<body>
<style>
body{background-color:cyan;}
body{text-align:center;}
</style>
<a href="Home.html">Previous</a><br><br>
</body>
</html>
<?php
//create server and database connection constants
$host = "localhost";
$user = "root";
$pwd = "";
$db = "farmers";

$con= new mysqli ($host, $user, $pwd, $db);
//Check server connection
if ($con->connect_error){
	die ("Connection failed:". $con->connect_error);
}else {
	echo "Thanks for Login to our services<br />";
		//receive  values from user form and trim white spaces
$name=trim($_POST["name"]);
$ps=trim($_POST["ps"]);

//now insert the received values into database using defined variables
$sqli ="INSERT INTO login(GroupUserName,GroupPassWord) VALUES ('$name','$ps')";
$ps= md5($ps);

if ($con->query($sqli) === TRUE) {
    echo "Login successfully Made";
} else {
    echo "Error: " . $sqli . "<br>" . $con->error;
}
$con->close(); //close the connection for security reason
}
?>