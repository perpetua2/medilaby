﻿<! DOCTYPE html>
<html>
<body>
<style>
body{background-color:cyan;}
body{text-align:center;}
</style>
<li><a href="Home.html"><b>Previous</b></a></li><br><br>
</body>
</html>
<?php
//create server and database connection constants
$host = "localhost";
$user = "root";
$pwd = "";
$db = "farmers";

$con= new mysqli ($host, $user, $pwd, $db);

//Check server connection
if ($con->connect_error){
	die ("Connection failed:". $con->connect_error);
}else {
	echo "Welcome all <br />";
		//receive  values from user form and trim white spaces
$name=trim($_POST['name']);
$psw=trim($_POST["psw"]);
 $psw= md5($psw);
 $phone=trim($_POST['phone']);
$gmembers=trim($_POST['gmembers']);
$chair=trim($_POST['chair']);
$pin=trim($_POST["pin"]);
$farming=trim($_POST['farming']);
$email=trim($_POST['email']);
$county=trim($_POST['county']);


//now insert the received values into database using defined variables
$sqli ="INSERT INTO register(UserName,PassWord,Phone,GroupMembers,GroupChairPerson,GroupKRAPIN,TypeOfFarming,Email,County) VALUES ('$name','$psw','$phone','$gmembers','$chair','$pin','$farming','$email','$county')";
if ($con->query($sqli) === TRUE) {
    echo "New FarmerGroups record created successfully";
} else {
    echo "Error: " . $sqli . "<br>" . $con->error;
}
$con->close(); //close the connection for security reason
}
if(!isset($login_session)){
mysql_close($connection); // Closing Connection
header('Location:Register.html'); // Redirecting To Home Page
}
?>