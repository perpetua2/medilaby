<html>
<head>
<link rel="stylesheet" href="BookNow.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body
{
	margin:0;
}
</style>
</head>
<body>
<div class="logo">

</div>

<link type="text/css" href="datesdesign.css" rel="stylesheet">
</head>
<body>
<form action="SelectDates.php" method="post">
<h1>Select Dates</h1>
<input type="date" class="input" placeholder="Choose Check In Date" name="in" required>
<br>
<br>
<input type="date" class="input" placeholder="Choose Check Out Date" name="out" required>
<br>
<br>
<input type="submit" class="input" name="submit" value="Continue">

</form>
</body>
</html>

<?php
if(isset($_POST['selectdate']))
{
session_start();	
//The variables that will hold the values from the form
$checkin=$_POST['checkin'];
$checkout=$_POST['checkout'];
//Confirm if the fields are empty
	if(empty($checkin)&&empty($checkout))
	{
		echo "<i style='color:red;text-align:center;margin-left:700px;'>The fields cannot be left empty</i>";
	}
	else
	{
	//Finding the number of days of stay for a person		
	$date1=date_create($checkin);
	$date2=date_create($checkout);		
	$datedif=date_diff($date1,$date2);
	$converteddata=$datedif->format("%R%a");

	//Connect to the database
	$dbconnect=mysqli_connect("localhost","root","","health");
	//Query to insert details into database
	$query="INSERT INTO dates(CheckIn,CheckOut,DaysOfStay,)VALUES('$checkin','$checkout','$converteddata')";
	//run the query of inserting data into the database
	$run_query=mysqli_query($dbconnect,$query);
			if($run_query)
			{ 
				echo "<i style='color:green;margin-left:700px;font-size:20px'>You have been checked in</i>";
			
			}
			else
			{
				echo "<i style='color:red;text-align:center'>The dates are already full</i>";
			}
	}
}
?>