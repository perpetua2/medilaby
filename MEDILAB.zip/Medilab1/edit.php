<!DOCTYPE html>
<html>
<body>
 <ul>
  <li><a class="active" href="doctor.html">Home</a></li>
 
</ul>
<div class="container">
    <h1>Edit Profile</h1>
  	<hr>
	<div class="row">
      <!-- left column -->
      <div class="col-md-3">
        <div class="text-center">
         
          <h6>Upload a different photo...</h6>
          
          <input type="file" class="form-control">
        </div>
      </div>
      
     
          
        <h3>Personal info</h3>
        
        <form class="form-horizontal" role="form" method="post">
          <div class="form-group">
            <label class="col-lg-3 control-label">First name:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" name="firstname">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Last name:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" name="lastname">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">County:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" name="county">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Email:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" name="email">
            </div>
          </div>
         
          <div class="form-group">
            <label class="col-md-3 control-label">Username:</label>
            <div class="col-md-8">
              <input class="form-control" type="text" name="username">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" name="password">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Confirm password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" name="confirmpassword">
          </div><br><br>
          <div class="form-group">
            <label class="col-md-3 control-label"></label>
            <div class="col-md-8">
              <input type="submit" class="btn btn-primary" value="SaveChanges" name="SaveChanges">
              <span></span>
              <input type="reset" class="btn btn-default" value="Cancel">
            </div>
          </div>
        </form>
      </div>
  </div>
</div>
</body>
</html>

<?php
if(isset($_POST['SaveChanges']))
{
//create server and database connection constants
$con=mysqli_connect('localhost','root','','health');

//receive  values from user form and trim white spaces
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$county=$_POST['county'];
$email=$_POST['email'];
$username=$_POST['username'];
$password=$_POST['password'];
$confirmpassword=$_POST['confirmpassword'];

//now insert the received values into database using defined variables
$sql="INSERT INTO profile(Firstname,Lastname,County,Email,Username,Password,Confirmpassword) VALUES('$firstname','$lastname','$county','$email','$username','$password','$confirmpassword')";


if (mysqli_query($con,$sql))
{
    echo "Your Profile has been made successfully";
} 
else 
{
    echo "Error inserting data";
}

}
?>