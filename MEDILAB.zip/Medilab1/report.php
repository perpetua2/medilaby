1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
<?php
  require('conn.php'); // connect your database using e.g. $connection = mysqli_connect(...)
  $query = "show table status";
  $result = mysqli_query($connection, $query);
  $ds = 0;
  $is = 0;
  echo "<table style='text-align:left;width:100%'>";
  echo "<tr  style='background:blue;color:yellow;'><th>Name</th><th>Data</th><th>Index</th></tr>";
  function format($c) {
    return (round($c / 1024, 2)) . 'KB';
  }
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr><th>" . ($row['Name']) . '</th>';
    echo "<th>" . format($row['Data_length']) . "</th>";
    echo "<th>" . format($row['Index_length']) . "</th>";
    $ds += $row['Data_length'];
    $is += $row['Index_length'];
    echo "</tr>";
  }
  echo "<tr style='background:lightblue;'>";
  echo "<th>". format($ds + $is) . "</th><th>" . format($ds) . "</th><th>" . format($is) . "</th>";
  echo "</tr></table>";
  ?> 