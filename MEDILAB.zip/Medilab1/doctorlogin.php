<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/register.css">
  <link rel="stylesheet" type="text/css" href="css/material.min.css">
  <link rel="stylesheet" type="text/css" href="css/MaterialIcons-Regular.woff">
  <script type="text/javascript" src="js/material.min.js"></script>
  <title>Medilab</title>
  <link rel="icon" href="dl6.png">
</head> 

<style type="text/css">
  @font-face{
    font-family: 'Material Icons';
    font-size: normal;
    font-weight: 400;
    src:url('css/MaterialIcons-Regular.woff');
  }
</style>

<body>

                </div>
<body>
  <style>
  #section {
    width:680px;
    float:left;
    padding:100px;     
}
body {
    margin: 0 auto;
    max-width: 600px;
    padding: 0 20px;
    height:500px;
}
body {
    margin: 0 auto;
    max-width: 500px;
    padding: 0 20px;
    height:500px;
}

/*
 Style all input fields */
input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
}

/* Style the submit button */
input[type=submit] {
    background-color: #4CAF50;
    color: white;
}

/* Style the container for inputs */
.container {
    background-color: #f1f1f1;
    padding: 20px;
}

/* The message box is shown when the user clicks on the password field */
#message {
    display:none;
    background: #f1f1f1;
    color: #000;
    position: relative;
    padding: 20px;
    margin-top: 10px;
}

#message p {
    padding: 10px 35px;
    font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
    color: green;
}

.valid:before {
    position: relative;
    left: -35px;
    content: "?";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
    color: red;
}

.invalid:before {
    position: relative;
    left: -35px;
    content: "?";
}
</style>
  <div class="header">
    <h2> Doctor Login</h2>
  </div>
   
  <form method="post" action="logg.php">
    <div class="input-group">
      <label>Username</label>
      <input type="text" name="users" required="username" placeholder="username" required="">
    </div><br>
    <div class="input-group">
      <label>Password</label>
      <input type="password" name="password" required="password"  placeholder="password" required>
    </div>
    <div class="input-group">
      <button type="submit" class="btn" name="login_user">Login</button>
    <p>
      Not Registered? <a href="Registration.html">Sign up</a><br>
      
    </p>
	</div>
  </form>
  </body>


<?php
if(isset($_POST['login_user']))
{
  $username=$_POST['username'];
  $password=$_POST['password'];

  if(empty($username)&&empty($password))
  {
    echo "<i style='color:red'>Fields cannot be left empty</i>";
  }
  else
  {
    $connect=mysqli_connect("localhost","root","","health");
    $query="SELECT register FROM users WHERE username='$username' AND Password='$password'";
    $run_query=mysqli_query($connect,$query);
    $fetch=mysqli_fetch_array($run_query);
    if($fetch['username']==$username && $fetch['Password']== $password)
		{
		echo "Details fetched Successfully";
	}
	else
	{
		echo "Error fetching details";
	}
      {
        echo "<i style='color:green'>Welcome </i>".$fetch['username'];
       
      }
	  {
		header("Location:doctor.html");
	}
      {
        echo "<div style='color:red'>Incorrect Username or password</div>";
      }
  }
}


?>


  
	<style>body
{background-color:cyan}
@media screen and (max-width: 320px)
{@viewport{ width:320px;}} @media screen and (min-width:500px) and (max-width:500px) { @viewport{width: 500px;}}
body{ background-color: cyan;}
</style>

</html>