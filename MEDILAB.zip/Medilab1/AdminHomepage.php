<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="AdminHomepage.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.styling
{
	margin-top:10px;
	margin-bottom:5px;
}
.bstyle
{
	padding:10px;
	
}
.desc
{
	padding:5px;
}
.whole
{
	text-align:center;
	border:1px solid black;
	width:200px;
	float:left;
	margin-left:20px;
	margin-top:20px;
}
.all
{
	margin-left:400px;
	margin-right:330px;
}
</style>
</head>
<body>
<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="#news">Customer Requests</a></li>
  <li class="dropdown">
    <a class="dropbtn" href="#contact">Settings</a>
	<div class="dropdown-content">
      <a href="#">Change Password</a>
      <a href="#">Change UserLogIn</a>
      <a href="#">Secret Questions</a>
    </div>
  </li>
  <li>
	<input type="text" name="search" placeholder="Enter Customer Name" class="form">
	<input type="submit" name="submit" value="Search" class="submit">
  </li>
  <li>
    <i class="fa fa-user" style="font-size:50px;margin-top:8px;color:black;margin-left:320px"></i>
  </li>
</ul>

<div class="all">
<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">Manage Rooms</button>
</div>
</div>

<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">View Customer</button>
</div>
</div>

<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">View Transactions</button>
</div>
</div>

<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">Manage Services</button>
</div>
</div>

<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">View Services Schedule</button>
</div>
</div>

<div class="whole">
<div class="styling">
<img src="niceroom.jpg" width="190px" height="150px">
</div>
<div class="desc">
<button class="bstyle" type="link" href="#">Customer Reviews</button>
</div>
</div>
</div>
</body>
</html>