<html>
<head>
<link type="text/css" href="AdminLogin.css" rel="stylesheet"> 
</head>
<body>
<form method="post" class="form">
<div class="image">
<img src="img/email1.jpg" width="400px" height="300px">
</div>
<div>
<h2>WELCOME TO MEDILAB</h2>
<p class="small">Please enter your admin login details</p>
<span style="font-size:20px">UserID</span>  &nbsp&nbsp&nbsp <input  class="pass" type="text" name="userid" required>
<br>
<br>
<span style="font-size:20px">Password</span> <input class="pass" type="password" name="pass" required>
<br>
<br>
<input class="submit" type="submit" name="submit" value="ENTER">
<br>
<br>
<a href="ForgotPassword.php" class="forgot">Forgot Password</a>
</div>
</form>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
	//We pick the form data that has been submitted
	$userid=$_POST['userid'];	
	$password=$_POST['pass'];
	//We connect to the database
	$connect=mysqli_connect("localhost","root","","health");
	//Query for checking if the user does exist
	$query="SELECT * FROM adminusers WHERE UserID='$userid' and Password='$password'";
	//Run the query
	$run_query=mysqli_query($connect,$query);
	//We then fetch the records in the database and compare to authenticate the details
	$row=mysqli_fetch_array($run_query);
	if($row['UserID']==$userid && $row['Password']==$password)
	{
		echo "<i style='color:green;margin-left:1050px;font-size:20px'>Welcome </i>".$row['UserName'];
	}
	else
	{
		echo "<i style='color:red;margin-left:1050px;font-size:20px'>Incorrect login details</i>";
	}
	{
		header("Location:AdminHomepage.html");
	}
}

?>