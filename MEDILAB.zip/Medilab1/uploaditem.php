<html>
<head>
<style>
.active
{
	margin-left:380px;
}
.stylefor
{
  padding:20px;
  width:400px;
  border:1px solid black;
  margin-left: 500px;
  text-align: center;
}

.styleme
{
  padding-left: 50px;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-right: 20px;
}

.stylebutt
{
  padding:10px;
  background-color: Dodgerblue;
}

body
{
	margin:0;
	padding:0;
}
ul 
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color:green;
	font-size:60px;
}

li 
{
    float: left;
}

li a
{
    display: inline-block;
    color: white;
    text-align: center;
    padding-top: 20px;
	padding-bottom:30px;
	padding-left:40px;
	padding-right:20px;
    text-decoration: none;
}

li a:hover 
{
    background-color: red;
}

.styleinput
{
	padding:10px;
}

.submit
{
	padding:10px;
	margin-top:15px;
	background-color:Dodgerblue;
}

.align
{
	margin-left:230px;
}
</style>
</head>
<body>
<ul>
  <li><a class="active" href="AdminHomepage.html">Home</a></li>

  </li>
</ul>
<br>
<form method="post" enctype="multipart/form-data" class="stylefor">
<h2>Add A New Doctor</h2>
<input type="file" name="image">
<br>
<br>
<input type="text" name="doctorname" placeholder="Enter Name of Doctor" class="styleme">
<br>
<br>
<select name="doctorcategory" class="styleme">
<option>...Select Doctor Category...</option>
<option value="surgeon">Surgeon</option>
<option value="audiologist">Audiologist</option>
<option value="physiologist">Physiologist</option>
<option value="pediatrician">Pediatrician</option>
<option value="densist">Densist</option>
</select>
<br>
<br>
<input type="date" name="employmentdate" placeholder="Enter Date of Employment Date" class="styleme">
<br>
<br>
<input type="text" name="doctorsalary" placeholder="Enter Salary" class="styleme">
<br>
<br>
<input type="text" name="county" placeholder="Enter County Name" class="styleme">
<br>
<br>
<input type="submit" name="adddoctor" value="Add Doctor" class="stylebutt">
<br>
<br>
</form>
</body>
</html>

<?php
if(isset($_POST['adddoctor']))
{
	//Get submitted data from form
	$doctorname=$_POST['doctorname'];
	$doctorcategory=$_POST['doctorcategory'];
	$doctorsalary=$_POST['doctorsalary'];
	$county=$_POST['county'];
	$itemid=rand();
	$employmentdate=$_POST['employmentdate'];
	$image=$_FILES['image']['name'];
	//Path to store image
	$target="images/".basename($_FILES['image']['name']);
	//Connect to the database
	$Connect=mysqli_connect("localhost","root","","health");
	//query to insert images
	$query="INSERT INTO doctors(Image,DoctorName,DoctorCategory,DoctorSalary,County,DateReceived,EmploymentDate) VALUES('$image','$doctorname','$doctorcategory','$doctorsalary','$county'
	,NOW(),'$employmentdate')";
	//run the query
	$run=mysqli_query($Connect,$query);
	//we now move the uploaded image into the folder image
	if(move_uploaded_file($_FILES['image']['tmp_name'],$target))
	{
		echo "Details Uploaded Successfully";
	}
	else
	{
		echo "Error uploading details";
	}
	{
		
	}
}
?>