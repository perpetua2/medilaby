<html>
	<head>
		<meta charset="UTF-8">
		<link rel="stylesheet" type="text/css" href="css/tablestyle.css">
		<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
		<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/local.css" />
		<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
		<script type="text/javascript" src="js/transition.js"></script>   
		<link rel="stylesheet" type="text/css" href="css/stylin.css">
		</head>
		<style>
			div
			{
				padding-bottom:-30px;
			}
		</style>
		
	<body>
	<div>
		<div  style="padding-top:40px;">
			<div class="table-users" style="background-image: url('.jpg');">
				<div class="header">Patients Selected</div>
						<table id="example" class="display" style="width:80%">
				<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>Subject</th>
    <th>Message</th>
	<th>County</th>
  </tr>
			  
				<?php
					include("config.php");
					
					$sql="SELECT * FROM appointments WHERE county = 'kitui' ";
					$result=mysqli_query($conn, $sql);
					if(mysqli_num_rows($result)>0)
					{
						while($row=mysqli_fetch_array($result))
						{
							echo"<tr>";
							echo"<td>".$row['Name']."</td>";
							echo"<td>".$row['Email']."</td>";
							echo"<td>".$row['Phone Number']."</td>";
							echo"<td>".$row['Subject']."</td>";
							echo"<td>".$row['Message']."</td>";
							echo"<td>".$row['County']."</td>";
							echo"</tr>";
						}
					}
				?>
						</table>
						<script src="js/jspdf.js"></script>
				</div>
				
				<div class="table-users" style="background-image: url('666.jpg');">
				<div class="header">Uploaded doctors</div>
					<table id="example" class="display" style="width:80%">
						<tr>
						<th>Image</th>
						<th>DoctorName</th>
						<th>DoctorCategory</th>
						<th>EmploymentDate</th>

						
						</tr>
						  
						<?php								
							$sql="SELECT * FROM doctors WHERE DoctorCategory = 'cardiologist' ";
							$result=mysqli_query($conn, $sql);
							if(mysqli_num_rows($result)>0)
							{
								while($myrow=mysqli_fetch_array($result))
								{
									echo"<tr>";
									echo"<td>".$myrow['Image']."</td>";
									echo"<td>".$myrow['ItemName']."</td>";
									echo"<td>".$myrow['ItemCategory']."</td>";
									echo"<td>".$myrow['ItemPrice']."</td>";
									echo"<td>".$myrow['ItemQuantity']."</td>";
									echo"<td>".$myrow['DateReceived']."</td>";
									echo"<td>".$myrow['ExpiryDate']."</td>";
									echo"<td>".$myrow['ItemID']."</td>";
									echo"</tr>";
								}
							}
						?>
					</table>
				</div>

		<div>
		<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="AdminHomepage.html">Back to Home</a>
            </div>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li><a href="uploaditem.php"><i class="fa fa-tasks"></i> Add New Items</a></li>
					<li><a href="reportsPage.php"><i class="fa fa-tasks"></i>Reports</a></li>
					<li><a href="generateReport.php"><i class="fa fa-tasks"></i>Generate Reports</a></li>
					
                </ul>
                <ul class="nav navbar-nav navbar-right navbar-user">
                     <li class="dropdown user-dropdown">
                            <li><a href="tuskys.html"><i class="fa fa-power-off"></i> Log Out</a></li>
                    </li>
                </ul>
            </div>
        </nav>
		</div>
		</div>
	</body>
</html>