<html>
<head></head>
<style>
.styling
{
	margin-top:10px;
	margin-bottom:5px;
}
.bstyle
{
	padding:10px;
	
}
.desc
{
	padding:5px;
}
.whole
{
	text-align:center;
	border:1px solid black;
	width:200px;
	float:left;
	margin-left:20px;
	margin-top:20px;
}
.all
{
	margin-left:400px;
	margin-right:330px;
}
.sidenav 
{
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a 
{
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover 
{
    color: #f1f1f1;
}

.sidenav .closebtn 
{
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

@media screen and (max-height: 450px) 
{
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

</style>
</head>
<body>
<form method="post">
<input type="text" name="number" placeholder="Enter Number please">
<br>
<br>
<input type="text" name="from" placeholder="Who is it from">
<br>
<br>
<textarea placeholder="Enter message please" name="message">
</textarea>
<br>
<br>
<input type="submit" name="submit" value="Send">
</form>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
	$uname="mainakevin13@gmail.com";
	$pass="Kevin1997g";

	$number=$_POST['number'];
	$from=$_POST['from'];
	$message=$_POST['message'];

	$var="uname=".$uname."&pword=".$pass."&message=".$message."&from=".$from."&number=".$number."&info=1&test=0";
	
	$curl=curl_init('http://www.txtlocal.com/sendsmspost.php');
	curl_setopt($curl,CURLOPT_POST,true);
	curl_setopt($curl,CURLOPT_POSTFIELDS,$var);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
	$result=curl_exec($curl);
	curl_close($curl);
	die("SMS Sent");
}
?>