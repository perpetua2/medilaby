<html>
<head>
<link type="text/css" href="SelectServices.css" rel="stylesheet">
<style>
body
{
	margin:0;
	padding:0;
}

nav
{
  overflow: auto;
  background: black;
  width: 100%;
}

ul
{
margin: 0 0 0 390px;
padding:0;
list-style-type: none;
overflow: hidden; 
}

li
{
float: left;
}

.logo h2
{
position: absolute;
margin-left: 20px;
margin-top: 15px;
font-size: 30px;
color:#FF00FF;
}

nav a
{
width: 100px;
display: block;
text-decoration: none;
color:white;
font-size: 18px;
text-align: center;
padding: 15px;
}
li a:hover
{
	background-color:red;
}

li
{
	padding: 10px;
}

.active
{
	background-color:red;
}

form
{
	margin-left:250px;
}

.whole
{
	border:1px solid black;
	width:250px;
	float:left;
	margin-right:20px;
	margin-bottom:20px;
}

.submit
{
	width:350px;
	padding-left:320px
}
</style>
</head>
<body>
<div class="logo">
<a href="home.html">
  <h2> Tuskys Supermarket </h2>
</a>
</div>
<nav>
<ul>
<li class="active"><a href="super.html">Home</a></li>
<li><a href="About.html">About</a></li>
<li><a href="contact.html">Contacts</a></li>

</ul>
</nav>

<br>

<h1 class="style">Available Doctors</h1>
<br>
<form method="post">
<div class="whole">
<img src="img/doctor1.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.100</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="a" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:<input type="checkbox" name="items[]" value="omo"></span>
</div>

<div class="whole">
<img src="dl4.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.100</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="b" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:<input type="checkbox" name="items[]" value="blueband"></span>
</div>

<div class="whole">
<img src="pampers.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.200</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="c" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:<input type="checkbox" name="items[]" value="pampers"></span>
</div>

<div class="whole">
<img src="sunlight.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.60</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="d" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:<input type="checkbox" name="items[]" value="soap"></span>
</div>

<div class="whole">
<img src="dl2.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.16,000</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="e" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:<input type="checkbox" name="items[]" value="TV"></span>
</div>

<div class="whole">
<img src="sofa.jpg" width="250px" height="250px">
<div class="description">
<br>
<span style="color:green">Price:sh.50000</span>
<br>
<span style="color:green">Enter Quantity:<input type="text" name="f" size="1"></span>
</div>
<span style="color:green;font-size:20px">Select:</span><input type="checkbox" name="items[]" value="coach">
</div>
<div class="submit">
<input type="submit" name="selecteditems" class="styleform" value="Select Items">
</div>
</form>

</body>
</html>

<?php
if(isset($_POST['selecteditems']))
{
	//Start a session
	session_start();
	$customerid=rand();
	$_SESSION['customerid']=$customerid;
	$selected=$_POST['items'];
	$a=$_POST['a'];
	$b=$_POST['b'];
	$c=$_POST['c'];
	$d=$_POST['d'];
	$e=$_POST['e'];
	$f=$_POST['f'];
	$connect=mysqli_connect("localhost","root","","supermarket");
	//We pick the checkbox values checked by client
	echo "<i style='color:green;margin-left:600px;font-size:22px'>You have selected the following services:</i>".'<br>'.'<br>';
	foreach($_POST['items'] as $selecteditems)
	{
		if($selecteditems=="omo")
		{
			$cost=50;
			$t=$cost*$a;
		}
		else if($selecteditems=="blueband")
		{
			$cost=100;
			$t=$cost*$b;
		}
		else if($selecteditems=="pampers")
		{
			$cost=200;
			$t=$cost*$c;
		}
		else if($selecteditems=="soap")
		{
			$cost=60;
			$t=$cost*$d;
		}
		else if($selecteditems=="TV")
		{
			$cost=16000;
			$t=$cost*$e;
		}
		else if($selecteditems=="coach")
		{
			$cost=50000;
			$t=$cost*$f;
		}
		echo '<i style="color:green;margin-left:640px;font-size:20px">'.' '.$selecteditems.' '."Ksh".'</i>'.' '.$t.'<br>'.'<br>';
		static $total;
		$total+=$t;
		$_SESSION['total']=$total;
		$chosen=implode(" ,",$selected);
	}
	echo "<i style='color:green;margin-left:620px;font-size:20px'>You total cost of services is:Ksh </i>".$total;
	$query="INSERT INTO customeritems(CustomerId,Items,TotalCost)VALUES('$customerid','$chosen','$total')";
	$run=mysqli_query($connect,$query);
	if($run)
	{
		echo "Items added";

	}
	else
	{
		echo "Error adding the data";
	}
}

?>
