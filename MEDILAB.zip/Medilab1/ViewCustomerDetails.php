<?php
//Connect to the database
$connect=mysqli_connect("localhost","root","","hotelmanagement");
//Query to view customer name,phone number,children and adults
$query="SELECT customerdetails.FullNames,customerdetails.PhoneNumber,roomdetails.Adults,roomdetails.Children FROM customerdetails INNER JOIN roomdetails ON 
customerdetails.CustomerID=roomdetails.CustomerID";
//run the query
$run_query=mysqli_query($connect,$query);
//fetch the number of rows
$count=mysqli_num_rows($run_query);
//fetch the records
if($count==0)
{
	echo "There are no customer records";
}
else
{
	while($row=mysqli_fetch_array($run_query))
	{
		$fullnames=$row['FullNames'];
		$phone=$row['PhoneNumber'];
		$adults=$row['Adults'];
		$children=$row['Children'];
		echo "<table border='1' style='border-collapse:collapse;width:250px'>";
		echo "<tr><td>" . $fullnames . "</td><td>" . $phone . "</td><td>". $adults ."</td><td>". $children ."</td></tr>";
		echo "</table>";
	}
}


?>