<html>
<head>
<link rel="stylesheet" href="items.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
<style type="text/css">
<style>
.active
{
	margin-left:380px;
}
.stylefor
{
  padding:20px;
  width:400px;
  border:1px solid black;
  margin-left: 500px;
  text-align: center;
}

.styleme
{
  padding-left: 50px;
  padding-top: 10px;
  padding-bottom: 10px;
  padding-right: 20px;
}

.stylebutt
{
  padding:10px;
  background-color: Dodgerblue;
}

body
{
	margin:0;
	padding:0;
}
ul 
{
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color:green;
	font-size:20px;
}

li 
{
    float: left;
}

li a
{
    display: inline-block;
    color: white;
    text-align: center;
    padding-top: 20px;
	padding-bottom:20px;
	padding-left:40px;
	padding-right:20px;
    text-decoration: none;
}

li a:hover 
{
    background-color: red;
}

.styleinput
{
	padding:10px;
}

.submit
{
	padding:10px;
	margin-top:15px;
	background-color:Dodgerblue;
}

.align
{
	margin-left:230px;
}
</style>
</head>

<ul>
  <li><a class="active" href="AdminHomepage.html">Home</a></li>
  
  </li>
  <li>
  <form method="post">
  <input type="text" name="search" placeholder="Search Product Name" class="styleinput">
  <input type="submit" name="submit" value="Search" class="submit">
  </form>
  </li>
  <li>
    <i class="img4.jpg" style="font-size:50px;margin-top:8px;color:black;margin-left:320px"></i>
  </li>
</ul>

<br>

<body> 


<table id="customers">
<table border="1" bordercolor="blue" bgcolor="white">
  <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>Subject</th>
    <th>Message</th>
	<th>County</th>
  </tr>
<?php
 function SearchProduct()
  {
  if(isset($_POST['submit']))
  {
  //Take the value from the search field
  $search=$_POST['search'];
  //Connect to the database
  $connect=mysqli_connect("localhost","root","","health");
  //Query to pick the data
  $query="SELECT * FROM appointments  WHERE County='$search'";
  //Run the query
  $run_query=mysqli_query($connect,$query);
  //Fetch the number of rows
  $rows=mysqli_num_rows($run_query);
  //check the number of rows in your database
    if($rows==0)
    {
      echo "No records found";
    }
    else
    {
      //Now let's loop through our database and fetch the records from the database
      while($fetch=mysqli_fetch_array($run_query))
        
          echo "<tr><td>".$fetch['name']."</td><td>". $fetch['email'] ."</td><td>" .$fetch['phone'] ."</td><td>". $fetch['subject'] 
		  ."</td><td>". $fetch['message'] ."</td><td>".$fetch['county']."</td><td>";
        }
    }
  } 
  
	  
SearchProduct();
?>

</table>

</body>
</html>